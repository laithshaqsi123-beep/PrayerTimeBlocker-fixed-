package com.salah.blocker

import android.content.Context
import org.json.JSONObject

data class City(val name: String, val lat: Double, val lng: Double)

val CITIES = listOf(
    City("مسقط", 23.5880, 58.3829), City("صلالة", 17.0151, 54.0924),
    City("صحار", 24.3643, 56.7461), City("نزوى", 22.9333, 57.5333),
    City("صور", 22.5667, 59.5289), City("الرستاق", 23.3908, 57.4244),
    City("عبري", 23.2257, 56.5157), City("البريمي", 24.2500, 55.7933),
    City("إبراء", 22.6903, 58.5339), City("بهلاء", 22.9714, 57.3050),
    City("سمائل", 23.3033, 57.9689), City("الخابورة", 23.9667, 57.0833),
    City("خصب", 26.1833, 56.2500), City("الدقم", 19.6667, 57.7000)
)

val DEFAULT_APPS = setOf(
    "com.instagram.android", "com.zhiliaoapp.musically", "com.ss.android.ugc.trill",
    "com.snapchat.android", "com.facebook.katana", "com.facebook.lite", "com.facebook.orca",
    "com.twitter.android", "com.google.android.youtube", "com.instagram.barcelona",
    "com.reddit.frontpage", "com.pinterest", "com.whatsapp", "com.whatsapp.w4b",
    "org.telegram.messenger", "org.telegram.messenger.web"
)

val DEFAULT_DOMAINS = setOf(
    "instagram.com", "tiktok.com", "snapchat.com", "facebook.com", "fb.com", "messenger.com",
    "x.com", "twitter.com", "t.co", "youtube.com", "youtu.be", "threads.net", "reddit.com",
    "pinterest.com", "whatsapp.com", "telegram.org", "t.me"
)

class Prefs(ctx: Context) {
    private val sp = ctx.applicationContext.getSharedPreferences("salah", Context.MODE_PRIVATE)

    var enabled: Boolean
        get() = sp.getBoolean("enabled", false)
        set(v) = sp.edit().putBoolean("enabled", v).apply()
    var duration: Int
        get() = sp.getInt("duration", 5)
        set(v) = sp.edit().putInt("duration", v.coerceIn(5, 30)).apply()
    var cityIdx: Int
        get() = sp.getInt("city", 0)
        set(v) = sp.edit().putInt("city", v).apply()
    var gpsLat: Double
        get() = sp.getString("glat", "0")!!.toDouble()
        set(v) = sp.edit().putString("glat", v.toString()).apply()
    var gpsLng: Double
        get() = sp.getString("glng", "0")!!.toDouble()
        set(v) = sp.edit().putString("glng", v.toString()).apply()
    var blockedApps: Set<String>
        get() = sp.getStringSet("apps", DEFAULT_APPS)!!.toSet()
        set(v) = sp.edit().putStringSet("apps", v).apply()
    var domains: Set<String>
        get() = sp.getStringSet("domains", DEFAULT_DOMAINS)!!.toSet()
        set(v) = sp.edit().putStringSet("domains", v).apply()
    var sig: String
        get() = sp.getString("sig", "")!!
        set(v) = sp.edit().putString("sig", v).apply()
    var lastFetchDay: String
        get() = sp.getString("fetchDay", "")!!
        set(v) = sp.edit().putString("fetchDay", v).apply()

    fun offset(i: Int) = sp.getInt("off$i", 0)
    fun setOffset(i: Int, v: Int) = sp.edit().putInt("off$i", v.coerceIn(-30, 30)).apply()

    fun times(): JSONObject = try { JSONObject(sp.getString("times", "{}")!!) } catch (e: Exception) { JSONObject() }
    fun putTimes(o: JSONObject) = sp.edit().putString("times", o.toString()).apply()

    fun latLng(): Pair<Double, Double> =
        CITIES.getOrNull(cityIdx)?.let { it.lat to it.lng } ?: (gpsLat to gpsLng)
}
