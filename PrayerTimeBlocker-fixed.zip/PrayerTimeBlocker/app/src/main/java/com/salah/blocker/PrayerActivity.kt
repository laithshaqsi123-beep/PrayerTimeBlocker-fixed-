package com.salah.blocker

import android.content.Intent
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import java.time.Duration
import java.time.ZonedDateTime

class PrayerActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setShowWhenLocked(true)
        setTurnScreenOn(true)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() = goHome()
        })
        setContent {
            AppTheme {
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    PrayerScreen(onDone = { finish() }, onHome = { goHome() })
                }
            }
        }
    }

    private fun goHome() {
        startActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }
}

@Composable
fun PrayerScreen(onDone: () -> Unit, onHome: () -> Unit) {
    val ctx = LocalContext.current
    var cur by remember { mutableStateOf(Scheduler.current(ctx)) }
    var left by remember { mutableLongStateOf(0L) }
    LaunchedEffect(Unit) {
        while (true) {
            val c = Scheduler.current(ctx)
            if (c == null) { onDone(); break }
            cur = c
            left = Duration.between(ZonedDateTime.now(), c.end).seconds.coerceAtLeast(0)
            delay(500)
        }
    }
    Surface(Modifier.fillMaxSize()) {
        Column(
            Modifier.fillMaxSize().padding(32.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text("🕌", fontSize = 72.sp)
            Spacer(Modifier.height(16.dp))
            Text("حان الآن وقت الصلاة، تقبل الله طاعتكم", style = MaterialTheme.typography.headlineSmall, textAlign = TextAlign.Center)
            cur?.let { Text("صلاة ${PrayerRepo.NAMES[it.idx]}", Modifier.padding(top = 8.dp), style = MaterialTheme.typography.titleMedium) }
            Spacer(Modifier.height(24.dp))
            Text("%02d:%02d".format(left / 60, left % 60), fontSize = 56.sp, color = MaterialTheme.colorScheme.primary)
            Text("المتبقي حتى فتح التطبيقات", Modifier.padding(top = 4.dp))
            Spacer(Modifier.height(32.dp))
            Button(onClick = onHome) { Text("الشاشة الرئيسية") }
        }
    }
}
